#pragma once
#ifndef OBJECT_H
#define OBJECT_H
#include "D3D.h"
#include <fbxsdk.h>
VOID CreateSphere(UINT);
XMMATRIX GetNodeMatrix(FbxNode*);
VOID LoadBones(FbxNode* , BONE* );
BONE* LoadBone(FbxNode* , BONE* );
BYTE BoneNameToIndex(const char* name);
VOID AddBoneInfluence(UINT vindex, BYTE boneIndex, FLOAT boneWeight);

VOID ImportFBX(LPCSTR);
#endif